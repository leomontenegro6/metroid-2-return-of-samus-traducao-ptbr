Jogo: Metroid II - Return of Samus
Vers�o: Americana
Console: Gameboy
Ano da tradu��o: 2008
Grupo de tradu��o: Trans-Center
Tradutor: Solid_One
MSN: the_solid_one@hotmail.com

---------------------NOTAS-------------------

O patch n�o funcionar� caso a rom n�o for a original de Gameboy. Caso seja algum hack, como as colora��es feitas de f�s pra f�s na internet, n�o garanto funcionamento do patch. Pois a pr�pria tradu��o j� inclui uma dessas colora��es.

-----------------SOBRE O JOGO----------------

Continua��o direta do Metroid de NES (tamb�m do Metroid Zero Mission, conseq�entemente), � o segundo jogo da s�rie Metroid, e tamb�m o �nico lan�ado para Gameboy. A jogabilidade � bastante parecida com seu predecessor de NES, por�m havendo melhorias gr�ficas e novos itens.

-------------------SINOPSE-------------------

Pouco tempo se passou desde que Samus destruiu a base dos Piratas Espaciais, situada em Zebes.

Anteriormente em Zebes, Samus tamb�m havia matado todos os Metr�ides e experimentos de procria��o destes seres, feitos pelos piratas l�.

Para evitar que algu�m fa�am mau uso dos Metr�ides, a Federa��o Gal�ctica envia uma nave de pesquisa ao planeta SR388, terra natal dos Metr�ides, para aniquilar a esp�cie. Por�m, estranhamente o contato com esta nave foi perdido pouco tempo depois de chegarem l�. Enviaram equipes de resgate e pelot�es de combate, um ap�s outro, para investigarem. Mas, nenhum deles voltou vivo.

Ao perceber a amea�a dos Metr�ides, a Federa��o Gal�ctica envia Samus a SR388, com uma miss�o: levar os Metr�ides � extin��o. Dever� aprofundar-se nas suas escuras cavernas, ca�ando e matando-os um por um.

Chegando l�, ela percebe que os Metr�ides em SR388 s�o muito mais fortes que os de antes. Os que ela matou em Zebes eram apenas larvas, enquanto que em SR388 a maioria deles est�o em formas mais evolu�das. L�, ela depara-se com v�rios tipos de Metr�ide: Alfa, Gama, Zeta, dentre outros.

Ser� ela capaz de cumprir tal miss�o?

---------------SOBRE A TRADU��O--------------

Estava entediado, dando uma olhadinha em umas roms de Gameboy. Ao ver o Metroid 2, percebi que o jogo � curto e tem pouqu�ssimos di�logos / gr�ficos.

Iniciei a tradu��o no meio dessa semana ainda. Foi uma boa experi�ncia pra ver como � o funcionamento de Gameboy. E como ningu�m chegou a traduzir esse jogo, senti-me mais motivado ainda em faz�-lo.

O jogo � de 1991, um dos primeiros do port�til, que na �poca era totalmente preto e branco. Por�m, encontrei na internet uns patches que alteram todo o arranjo de cores do Metroid 2, deixando-o colorido igual a um jogo de Gameboy Color. Assim, ficando muito melhor graficamente. Por�m, com esse patch, o jogo n�o rodar� mais em Gameboy comum. S� no Gameboy Color pra cima.

Isso � tudo. Usufruam do privil�gio \o/

--------------STATUS DA TRADU��O-------------

Textos: 100%
(Pouqu�ssimos di�logos.)

Acentos: 100%
(Foi complicado arrumar espa�o pros acentos, mas deu certo no fim das contas.)

Gr�ficos: 100%
(Tudo descomprimido e extremamente f�cil de achar)

---------------AGRADECIMENTOS----------------

-Zorlon, pelo patch de colora��o que usei junto com a tradu��o
-Darkl0rd, por ajudar na tradu��o de alguns termos
	
------------------HIST�RIA-------------------

Vers�o 1.0 - 06/02/08
 Primeiro lan�amento. Vers�o Americana

------------------COR�COR�-------------------

Se voc� encontrou algum erro ortogr�fico, de concord�ncia ou algo parecido, por favor relate a mim por e-mail ou por MSN. Voc� encontra meu MSN no topo do arquivo.